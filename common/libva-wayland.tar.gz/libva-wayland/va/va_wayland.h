#ifndef _VA_WAYLAND_H_
#define _VA_WAYLAND_H_

#include <va/va.h>
#include <wayland-client.h>
#include <wayland-egl.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Returns a suitable VADisplay for VA API
 */
VADisplay vaGetDisplay (
    struct wl_display *display
);

/*
 * Output rendering
 * Following is the rendering interface for wayland surfaces, 
 * to get the decode output surface to a wayland surface
 * It basically performs a de-interlacing (if needed), 
 * color space conversion and scaling to the destination
 * rectangle
 */
VAStatus vaPutSurface (
    VADisplay dpy,
    VASurfaceID surface,	
    void *draw, /* wl_egl_window or wl_egl_pixmap */
    short srcx,
    short srcy,
    unsigned short srcw,
    unsigned short srch,
    short destx,
    short desty,
    unsigned short destw,
    unsigned short desth,
    VARectangle *cliprects, /* client supplied destination clip list */
    unsigned int number_cliprects, /* number of clip rects in the clip list */
    unsigned int flags /* PutSurface flags */
);

#ifdef __cplusplus
}
#endif

#endif /* _VA_WAYLAND_H_ */
