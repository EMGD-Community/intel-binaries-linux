/*
 * Copyright (c) 2011 Intel Corporation. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 * 
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#include "va.h"
#include "va_backend.h"
#include "va_wayland.h"
#include "egl/va_backend_egl.h"
#include "va_drmcommon.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <assert.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <wayland-client.h>
#include <wayland-util.h>
#include "wayland-emgd-client-protocol.h"
#include "wayland-egl-priv.h"

#include <intel_bufmgr.h>

struct wldrm_ctx {
	struct VADriverContext base;

	struct wl_emgd *drm;
	int authenticated;

	drm_intel_bufmgr *bufmgr;
};

struct wldrm_buffer {
	union drm_buffer base;
	drm_intel_bo *bo;
	struct wl_buffer *buf;

};

enum wldrm_buffer_type {
	WLDRM_BUFFER_FRONT,
	WLDRM_BUFFER_BACK,
	WLDRM_BUFFER_COUNT
};

#define DRAWABLE_HASH_SZ 32
struct wldrm_drawable {
	struct drm_drawable base;
	int is_window;
	struct wl_egl_window *win;

	int block_swap_buffers;

	struct wldrm_buffer *buffer[WLDRM_BUFFER_COUNT];

	struct wldrm_drawable *next;
};

struct wldrm_state {
	struct drm_state base;
	struct wldrm_drawable *drawable_hash[DRAWABLE_HASH_SZ];
};

enum {
	__DRI_BUFFER_FRONT_LEFT = 0,
	__DRI_BUFFER_BACK_LEFT,
	__DRI_BUFFER_FRONT_RIGHT,
	__DRI_BUFFER_BACK_RIGHT,
	__DRI_BUFFER_DEPTH,
	__DRI_BUFFER_STENCIL,
	__DRI_BUFFER_ACCUM,
	__DRI_BUFFER_FAKE_FRONT_LEFT, 
	__DRI_BUFFER_FAKE_FRONT_RIGHT
};

/* Cast helpers */

static inline struct wldrm_ctx *
wldrm_ctx(struct VADriverContext *driver_ctx)
{
	return (struct wldrm_ctx *) driver_ctx;
}

static inline struct wldrm_drawable *
wldrm_drawable(struct drm_drawable *drawable)
{
	return (struct wldrm_drawable *) drawable;
}

static inline struct VADriverContext *
va_driver_ctx(struct VADisplayContext *display_ctx)
{
	return display_ctx->pDriverContext;
}

/* Wayland utility */

static void
sync_callback(void *data)
{
	int *done = data;

	*done = 1;
}

static void
force_roundtrip(struct wl_display *display)
{
	int done = 0;

	wl_display_sync_callback(display, sync_callback, &done);
	wl_display_iterate(display, WL_DISPLAY_WRITABLE);
	while (!done)
		wl_display_iterate(display, WL_DISPLAY_READABLE);
}

static inline uint32_t
surface_get_id(struct wl_surface *surface)
{
	struct wl_object *object = (struct wl_object *) surface;

	return object->id;
}

static inline struct wl_emgd *
wl_drm_create_without_bind(struct wl_display *display, uint32_t id)
{
	return (struct wl_emgd *)
		wl_proxy_create_for_id(display, &wl_emgd_interface, id);
}

static inline int
align(int value, int alignment)
{
	return (value + alignment - 1) & ~(alignment - 1);
}

static drm_intel_bo *
bo_alloc(struct wldrm_ctx *wctx,
	 int width, int height, int cpp,
	 int *name, int *pitch)
{
	drm_intel_bo *bo;
	int size;

	*pitch = align(width, 64) * cpp;
	size = *pitch * align(height, 4);

	bo = drm_intel_bo_alloc_for_render(wctx->bufmgr,
					   "render buffer", size, 0);
	if (drm_intel_bo_flink(bo, name))
		fprintf(stderr, "flink failed for bo: %p\n", bo);

	return bo;
}

static void
drm_handle_device(void *data, struct wl_emgd *drm, const char *device)
{
	struct wldrm_ctx *wctx = data;
	struct drm_state *drm_state = wctx->base.drm_state;
	drm_magic_t magic;
	struct stat st;

	/* FIXME: I am hardcoding device here because the passed in device seems invalid.
	 * 	  I need to find out why.
	 */

	if (stat("/dev/dri/card0", &st) == -1) {
		fprintf(stderr, "Cannot identify '%s': %d, %s\n",
			device, errno, strerror(errno));
		return;
	}

	if (!S_ISCHR(st.st_mode)) {
		fprintf(stderr, "%s is no device\n", device);
		return;
	}

	drm_state->fd = open("/dev/dri/card0", O_RDWR);
	if (drm_state->fd == -1) {
		fprintf(stderr, "Cannot open '%s': %d, %s\n",
			device, errno, strerror(errno));
		return;
	}

	drmGetMagic(drm_state->fd, &magic);
	
	/* No authentication support now 
 	 * so set wct->authenticated manually 
 	 */
	wctx->authenticated = 1;
//	wl_drm_authenticate(wctx->drm, magic);
}

static void
drm_handle_authenticated(void *data, struct wl_emgd *drm)
{
	struct wldrm_ctx *wctx = data;

	wctx->authenticated = 1;
}

static const struct wl_emgd_listener drm_listener = {
	drm_handle_device,
	drm_handle_authenticated
};

static VAStatus
wldrm_display_ctx_get_driver_name(struct VADisplayContext *display_ctx,
				  char **driver_name)
{
	struct wldrm_ctx *wctx = wldrm_ctx(va_driver_ctx(display_ctx));
	struct drm_state *drm_state = wctx->base.drm_state;
	struct wl_display *display = wctx->base.native_dpy;
	uint32_t id;

	memset(drm_state, 0, sizeof(*drm_state));
	id = wl_display_get_global(display, "wl_emgd", 1);
	if (id == 0) {
		//force_roundtrip(display);
		wl_display_roundtrip(display);
		id = wl_display_get_global(display, "wl_emgd", 1);
	}
	if (id == 0) {
		goto error_unknown;
	}
	wctx->drm = wl_display_bind(display, id, &wl_emgd_interface);
	if (!wctx->drm) {
		goto error_unknown;
	}
	wl_emgd_add_listener(wctx->drm, &drm_listener, wctx);
        wl_display_roundtrip(display);

	if (drm_state->fd == -1) {
		fprintf(stderr, "can't open DRM devices\n");
		goto cleanup_drm;
	}

	wl_display_roundtrip(display);

	if (!wctx->authenticated) {
		goto cleanup_fd;
	}

	*driver_name = strdup("emgd");
	drm_state->driConnectedFlag = VA_DRI2;

	wl_emgd_destroy(wctx->drm);
	wctx->drm = NULL;

	return VA_STATUS_SUCCESS;

cleanup_fd:
	close(drm_state->fd);
	drm_state->fd = -1;
cleanup_drm:
	wl_emgd_destroy(wctx->drm);
error_unknown:
	return VA_STATUS_ERROR_UNKNOWN;
}

static int
wldrm_display_ctx_is_valid(struct VADisplayContext *display_ctx)
{
	return (display_ctx != NULL && va_driver_ctx(display_ctx) != NULL);
}

static void 
wldrm_display_ctx_destroy(struct VADisplayContext *display_ctx)
{
	struct wldrm_ctx *wctx;
	struct drm_state *drm_state;

	if (!wldrm_display_ctx_is_valid(display_ctx))
		return;

	wctx = wldrm_ctx(va_driver_ctx(display_ctx));
	drm_state = wctx->base.drm_state;

	close(drm_state->fd);

	free(drm_state);
	free(wctx);
	free(display_ctx);
}

VADisplay
vaGetDisplay(struct wl_display *native_dpy)
{
	VADisplay dpy = NULL;
	struct VADisplayContext *display_ctx;

	if (!native_dpy)
		return NULL;

	if (!dpy) {
		/* create new entry */
		struct wldrm_ctx *wctx;
		struct wldrm_state *drm_state;

		display_ctx = calloc(1, sizeof *display_ctx);
		wctx        = calloc(1, sizeof *wctx);
		drm_state   = calloc(1, sizeof *drm_state);

		if (display_ctx && wctx && drm_state) {
			display_ctx->vadpy_magic = VA_DISPLAY_MAGIC;          
			display_ctx->pDriverContext = &wctx->base;
			display_ctx->vaGetDriverName =
				wldrm_display_ctx_get_driver_name;
			display_ctx->vaIsValid  = wldrm_display_ctx_is_valid;
			display_ctx->vaDestroy = wldrm_display_ctx_destroy;

			wctx->base.native_dpy = native_dpy;
			wctx->base.drm_state  = drm_state;

			dpy = (VADisplay) display_ctx;
		} else {
			if (display_ctx)
				free(display_ctx);
			if (wctx)
				free(wctx);
			if (drm_state)
				free(drm_state);
		}
	}

	return dpy;
}

#define CTX(dpy) (va_driver_ctx((struct VADisplayContext *)dpy))
#define CHECK_DISPLAY(dpy) \
	if( !wldrm_display_ctx_is_valid(dpy) ) { \
	return VA_STATUS_ERROR_INVALID_DISPLAY; }

extern int fool_postp; /* do nothing for vaPutSurface if set */
extern int trace_flag; /* trace vaPutSurface parameters */

void 
va_TracePutSurface(VADisplay dpy,
		   VASurfaceID surface,
		   void *draw,
		   short srcx, short srcy,
		   unsigned short srcw, unsigned short srch,
		   short destx, short desty,
		   unsigned short destw, unsigned short desth,
		   VARectangle *cliprects,
		   unsigned int number_cliprects,
		   unsigned int flags);

#define VA_TRACE(trace_func,...)		\
	if (trace_flag) {			\
		trace_func(__VA_ARGS__);	\
	}

VAStatus
vaPutSurface(VADisplay dpy,
	     VASurfaceID surface,
	     void *draw,
	     short srcx, short srcy,
	     unsigned short srcw, unsigned short srch,
	     short destx, short desty,
	     unsigned short destw, unsigned short desth,
	     VARectangle *cliprects, /* client supplied clip list */
	     /* number of clip rects in the clip list */
	     unsigned int number_cliprects,
	     unsigned int flags /* de-interlacing flags */)
{
	struct VADriverContext *ctx;

	if (fool_postp)
		return VA_STATUS_SUCCESS;

	if (draw == NULL)
		return VA_STATUS_ERROR_UNKNOWN;

	CHECK_DISPLAY(dpy);
	ctx = CTX(dpy);

	VA_TRACE(va_TracePutSurface, dpy, surface, draw,
		 srcx, srcy, srcw, srch,
		 destx, desty, destw, desth,
		 cliprects, number_cliprects, flags);

	return ctx->vtable->vaPutSurface(ctx, surface, draw,
					 srcx, srcy, srcw, srch,
					 destx, desty, destw, desth,
					 cliprects, number_cliprects, flags);
}
