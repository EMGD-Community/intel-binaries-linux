#ifndef _VA_DRMCOMMON_H_
#define _VA_DRMCOMMON_H_

#ifndef ANDROID
#include <xf86drm.h>
#include <drm.h>
#include <drm_sarea.h>
#endif

#include <va/va_backend.h>

enum
{
    VA_NONE = 0,
    VA_DRI1 = 1,
    VA_DRI2 = 2,
    VA_DUMMY = 3
};

union drm_buffer 
{
    struct {
        unsigned int attachment;
        unsigned int name;
        unsigned int pitch;
        unsigned int cpp;
        unsigned int flags;
    } dri2;

    struct {
    } dri1;
};

struct drm_drawable 
{
    int x;
    int y;
    unsigned int width;
    unsigned int height;
};

struct drm_state 
{
    int fd;
    int driConnectedFlag; /* 0: disconnected, 1: DRM, 2: DRM2 */
#ifndef ANDROID
    drm_handle_t hSAREA;
    drm_context_t hwContext;
    drmAddress pSAREA;

    struct drm_drawable *(*getDrawable)(VADriverContextP ctx, void *native_drawable);

    void (*swapBuffer)(VADriverContextP ctx, struct drm_drawable *drm_drawable);
    union drm_buffer *(*getRenderingBuffer)(VADriverContextP ctx, struct drm_drawable *drm_drawable);
#endif

    /* To be implemented by the driver */
    VAStatus (*image_export)(VADriverContextP ctx, VAImageID image,
                             unsigned int *name, unsigned int *pitch);

};

#endif /* _VA_DRMCOMMON_H_ */
