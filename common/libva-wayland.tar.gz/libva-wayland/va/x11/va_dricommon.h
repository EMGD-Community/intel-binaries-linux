#ifndef _VA_DRICOMMON_H_
#define _VA_DRICOMMON_H_

#include <va_drmcommon.h>

#ifndef ANDROID
#include <X11/Xlib.h>
#endif

#include <va/va_backend.h>

#ifdef ANDROID
#define XID unsigned int
#define Bool int
#endif

#define dri_buffer drm_buffer

struct dri_drawable 
{
    struct drm_drawable base;
    XID x_drawable;
    int is_window;

    struct dri_drawable *next;
};

#define DRAWABLE_HASH_SZ 32
struct dri_state 
{
    struct drm_state base;

#ifndef ANDROID
    XID hwContextID;
    struct dri_drawable *drawable_hash[DRAWABLE_HASH_SZ];

    struct dri_drawable *(*createDrawable)(VADriverContextP ctx, XID x_drawable);
    void (*destroyDrawable)(VADriverContextP ctx, struct dri_drawable *dri_drawable);
    void (*close)(VADriverContextP ctx);
#endif
};

Bool isDRI2Connected(VADriverContextP ctx, char **driver_name);
Bool isDRI1Connected(VADriverContextP ctx, char **driver_name);
void free_drawable(VADriverContextP ctx, struct dri_drawable* dri_drawable);
void free_drawable_hashtable(VADriverContextP ctx);
struct drm_drawable *dri_get_drawable(VADriverContextP ctx, void *drawable);
void dri_swap_buffer(VADriverContextP ctx, struct dri_drawable *dri_drawable);
union dri_buffer *dri_get_rendering_buffer(VADriverContextP ctx, struct dri_drawable *dri_drawable);

#endif /* _VA_DRICOMMON_H_ */
