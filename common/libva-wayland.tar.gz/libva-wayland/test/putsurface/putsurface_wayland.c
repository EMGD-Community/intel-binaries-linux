/*
 * Copyright (c) 2011 Intel Corporation. All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sub license, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 * 
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial portions
 * of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.
 * IN NO EVENT SHALL PRECISION INSIGHT AND/OR ITS SUPPLIERS BE LIABLE FOR
 * ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#include <wayland-client.h>
#include <wayland-egl.h>
#include <va/va_wayland.h>

#include <sys/select.h>
#include <errno.h>

static void *open_display(void);
static void close_display(void *win_display);
static int create_window(void *win_display,
			 int x, int y, int width, int height);
static int check_window_event(void *win_display, void *drawable,
			      int *width, int *height, int *quit);

#define CAST_DRAWABLE(a)  (struct wl_egl_window *)(a)

#include "putsurface_common.c"

struct display {
	struct wl_display *display;
	struct wl_visual *rgb_visual;
	struct wl_compositor *compositor;
	struct wl_shell *shell;
	uint32_t mask;
	int event_fd;
};

static void
compositor_handle_visual(void *data,
                         struct wl_compositor *compositor,
                         uint32_t id, uint32_t token)
{
        struct display *d = data;

        switch (token) {
        case WL_COMPOSITOR_VISUAL_XRGB32:
                d->rgb_visual = wl_visual_create(d->display, id, 1);
                break;
        }
}

static const struct wl_compositor_listener compositor_listener = {
        compositor_handle_visual,
};

static void
display_handle_global(struct wl_display *display, uint32_t id,
                      const char *interface, uint32_t version, void *data)
{
        struct display *d = data;

        if (strcmp(interface, "wl_compositor") == 0) {
                d->compositor = wl_compositor_create(display, id, 1);
                wl_compositor_add_listener(d->compositor,
                                           &compositor_listener, d);
        } else if (strcmp(interface, "wl_shell") == 0) {
                d->shell = wl_shell_create(display, id, 1);
        }
}

static int
event_mask_update(uint32_t mask, void *data)
{
	struct display *d = data;

	d->mask = mask;

	return 0;
}

static void *open_display(void)
{
	struct display *d;
	
	d = calloc(1, sizeof *d);
	if (!d)
		return NULL;
	memset(d, 0, sizeof *d);

	d->display = wl_display_connect(NULL);
	if (!d->display)
		return NULL;

	wl_display_set_user_data(d->display, d);
	wl_display_add_global_listener(d->display,
				       display_handle_global, d);
	d->event_fd = wl_display_get_fd(d->display, event_mask_update, d);

#if 1
	wl_display_iterate(d->display, d->mask);
#else
	wl_display_iterate(d->display, WL_DISPLAY_READABLE);
	wl_display_flush(d->display);
#endif

	return d->display;
}

static void
close_display(void *win_display)
{
	struct display *d = wl_display_get_user_data(win_display);

	free(d);
	wl_display_destroy(win_display);
}

static void
sync_callback(void *data)
{
	int *done = data;

	*done = 1;
}

static int
create_window(void *win_display, int x, int y, int width, int height)
{
	struct wl_display *display = win_display;
	struct display *d = wl_display_get_user_data(display);
	struct wl_surface *surface;
	struct wl_egl_window *win;
	int done = 0;

	if (!d->rgb_visual) {
		wl_display_sync_callback(d->display, sync_callback, &done);
		while (!done)
			wl_display_iterate(d->display, d->mask);
		if (!d->rgb_visual) {
			fprintf(stderr, "rgb visual missing\n");
			exit(1);
		}
	}

	surface = wl_compositor_create_surface(d->compositor);

	win = wl_egl_window_create(surface, width, height, d->rgb_visual);
	wl_shell_set_toplevel(d->shell, surface);

	/* global out */
	drawable_thread0 = win;

	if (multi_thread == 0)
		return 0;

	surface = wl_compositor_create_surface(d->compositor);

	win = wl_egl_window_create(surface, width, height, d->rgb_visual);
	wl_shell_set_toplevel(d->shell, surface);

	/* global out */
	drawable_thread1 = win;

	return 0;
}

static int check_window_event(void *win_display, void *drawable,
			      int *width, int *height, int *quit)
{
	struct wl_display *display = (struct wl_display *) win_display;
	struct display *d = wl_display_get_user_data(display);
	struct wl_egl_window *win = (struct wl_egl_window *) drawable;
	struct timeval tv;
	fd_set rfds;
	int retval;

	if (check_event == 0)
		return 0;

	if (!(d->mask & WL_DISPLAY_READABLE))
		return;

	tv.tv_sec  = 0;
	tv.tv_usec = 0;
	do {
		FD_ZERO(&rfds);
		FD_SET(d->event_fd, &rfds);

		retval = select(d->event_fd + 1, &rfds, NULL, NULL, &tv);
		if (retval < 0) {
			fprintf(stderr, "select faild: %s\n", strerror(errno));
			break;
		}
		if (retval == 1)
			wl_display_iterate(d->display, WL_DISPLAY_READABLE);
	} while (retval > 0);


#if 0
	/* bail on any focused key press */
	if(event.type == KeyPress) {  
		*quit = 1;
		return 0;
	}
#endif

#if 0
	/* rescale the video to fit the window */
	if(event.type == ConfigureNotify) { 
		*width = event.xconfigure.width;
		*height = event.xconfigure.height;
		printf("Scale window to %dx%d\n", width, height);
	}
#endif

	return 0;
}
