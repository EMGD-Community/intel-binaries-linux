#! /bin/sh
autoreconf -v --install
./configure "$@"
